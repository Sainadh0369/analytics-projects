# ETL Pipeline Development

**Description:** A Python project to create an ETL pipeline using AWS services like S3, Lambda, and RedShift.

## Tools and Libraries Used:
- Boto3
- Pandas

## Steps:
1. Extract data from AWS S3 using Boto3.
1. Clean and transform the data.
1. Load the transformed data into AWS RedShift.
1. Write and document the pipeline process in Python.

## How to Run:
Follow the steps in the provided code or Tableau file to execute the project.
