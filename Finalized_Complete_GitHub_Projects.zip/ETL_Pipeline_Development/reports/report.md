
# ETL Pipeline Development

## Dataset Overview
- **Structured Records**: 20 rows with fields: ID, Name, Age, Department, Salary.
- **Unstructured Data**: Employee feedback in raw text format.

## Process
1. Extracted structured and unstructured data.
2. Parsed unstructured data for feedback comments.
3. Merged structured data with feedback and enriched it with salary brackets.

## Key Outputs
- Transformed dataset includes employee details, feedback, and salary brackets.

## How to Run
1. Load raw data from `data/structured_data.csv` and `data/unstructured_data.txt`.
2. Run the ETL process in `main.py` to generate the transformed dataset.
