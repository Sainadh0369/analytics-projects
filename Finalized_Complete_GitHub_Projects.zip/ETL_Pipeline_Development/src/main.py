
import pandas as pd

# ETL Pipeline Function
def etl_pipeline():
    # Load structured data
    structured = pd.read_csv('../data/structured_data.csv')
    
    # Process unstructured data
    with open('../data/unstructured_data.txt', 'r') as file:
        lines = file.readlines()
    feedback_data = [line.strip().split(', Feedback: ') for line in lines if 'ID:' in line]
    feedback_df = pd.DataFrame(feedback_data, columns=['Raw', 'Feedback'])
    feedback_df['ID'] = pd.to_numeric(feedback_df['Raw'].str.extract(r'ID: (\d+)')[0], errors='coerce')
    feedback_df = feedback_df.dropna(subset=['ID']).astype({'ID': int})[['ID', 'Feedback']]
    
    # Join datasets
    result = pd.merge(structured, feedback_df, on='ID', how='left')
    
    # Transform data
    result['Salary Bracket'] = pd.cut(
        result['Salary'], bins=[0, 70000, 100000, 150000], labels=['Low', 'Medium', 'High']
    )
    return result

# Run the pipeline
output = etl_pipeline()
output.to_csv('../output/transformed_data.csv', index=False)
