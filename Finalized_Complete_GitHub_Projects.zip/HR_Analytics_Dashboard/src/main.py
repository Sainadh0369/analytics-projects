
import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv('../data/data.csv')

# Group by department and calculate average engagement scores
avg_scores = data.groupby('Department')['Engagement_Score'].mean()

# Plot data
plt.figure(figsize=(10, 6))
avg_scores.plot(kind='bar', color=['blue', 'orange', 'green'])
plt.xlabel('Department')
plt.ylabel('Average Engagement Score')
plt.title('Average Engagement Score by Department')
plt.tight_layout()
plt.savefig('../output/output_plot.png')
