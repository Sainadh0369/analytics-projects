
# Predictive Sales Analytics Report (Synthetic Data)

## Dataset Overview
- **Records**: 36 months of sales data
- **Sales Range**: 5189 to 14998 units

## Observations
- The sales trend indicates consistent growth over the years.
- Predicted sales for the next 12 months show continued upward momentum.

## Methodology
1. Loaded and cleaned synthetic sales data.
2. Conducted regression analysis to model the trendline.
3. Forecasted future sales based on the regression model.

## Key Outputs
The following graph shows the actual sales trend and the forecast for the next 12 months:

![Synthetic Sales Forecast Plot](../output/synthetic_sales_forecast.png)

## Tools Used
- Python (Pandas, NumPy, Matplotlib)

## Instructions
1. Load the dataset from `data/sales_data.csv`.
2. Use the provided `main.py` script to reproduce the analysis and generate updated forecasts.
