
# HR Analytics Dashboard

## Dataset Overview
- **Records**: 100 employees.
- **Departments**: Sales, HR, Engineering.
- **Engagement Score Range**: 50 to 100.
- **Attrition Rate Range**: 0.0 to 0.2.

## Key Outputs
- The output plot shows engagement scores by department.

## How to Run
1. Load the dataset from `data/data.csv`.
2. Use `main.py` in the `src/` folder to generate the plot.
