
# HR Analytics Dashboard Report

## Dataset Overview
- **Records**: 100 employees
- **Departments**: Sales, HR, Engineering, Marketing
- **Engagement Score Range**: 50 to 98
- **Attrition Rate Range**: 0.0 to 0.2
- **Diversity Score Range**: 70 to 99

## Observations
- Employees in Engineering show higher engagement scores on average.
- Attrition rates are higher in Sales compared to other departments.
- Diversity scores are evenly distributed across departments.

## Methodology
1. Loaded and analyzed synthetic HR data.
2. Visualized key metrics like engagement, attrition, and diversity.

## Key Outputs
Visualizations for HR metrics can be developed using tools like Tableau or Python.

## Tools Used
- Python (Pandas, Matplotlib) or Tableau

## Instructions
1. Load the dataset from `data/hr_data.csv`.
2. Use Tableau or Python for visualizations and analysis.
