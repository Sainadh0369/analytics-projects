
# HR Analytics Dashboard Instructions

## Overview
This project visualizes key HR metrics, including:
- Employee Engagement Scores
- Attrition Rates by Department
- Diversity Scores

## Dataset
The dataset (`hr_data.csv`) contains 100 sample records with the following fields:
- Employee_ID: Unique identifier for each employee.
- Department: The department of the employee (e.g., Sales, HR).
- Engagement_Score: A score representing employee engagement (50-100).
- Attrition_Rate: The likelihood of the employee leaving (0-0.2).
- Diversity_Score: A score for diversity representation (70-100).

## Tools Used
- Tableau for visualization.
