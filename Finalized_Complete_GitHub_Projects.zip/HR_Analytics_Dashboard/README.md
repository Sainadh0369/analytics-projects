# HR Analytics Dashboard

**Description:** An interactive Tableau dashboard showcasing HR metrics such as employee engagement, attrition rates, and diversity.

## Tools and Libraries Used:
- Tableau

## Steps:
1. Import and clean HR analytics data.
1. Create visualizations for employee engagement, attrition rates, and diversity metrics.
1. Design an interactive dashboard.
1. Publish the dashboard on Tableau Public or export visuals.

## How to Run:
Follow the steps in the provided code or Tableau file to execute the project.
